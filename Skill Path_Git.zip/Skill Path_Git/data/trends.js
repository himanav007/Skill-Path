export const trends = [
    {
        id: 1,
        title: "The Rise of AI Engineers",
        source: "TechCrunch",
        date: "2h ago",
        summary: "Why AI engineering is becoming the most sought-after role in 2025.",
        category: "AI",
        url: "#"
    },
    {
        id: 2,
        title: "React Server Components: A Deep Dive",
        source: "Vercel Blog",
        date: "1d ago",
        summary: "Understanding the paradigm shift in building modern React applications.",
        category: "Frontend",
        url: "#"
    },
    {
        id: 3,
        title: "Rust in the Linux Kernel",
        source: "The Verge",
        date: "3d ago",
        summary: "How Rust is making low-level programming safer and more accessible.",
        category: "Systems",
        url: "#"
    }
];
