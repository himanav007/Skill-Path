export const courses = [
    {
        id: 1,
        title: "Advanced React Patterns",
        provider: "Frontend Masters",
        duration: "6h 30m",
        level: "Advanced",
        tags: ["React", "JavaScript", "Frontend"],
        image: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&q=80",
        url: "#"
    },
    {
        id: 2,
        title: "Next.js 14: The Complete Guide",
        provider: "Udemy (Free)",
        duration: "12h",
        level: "Intermediate",
        tags: ["Next.js", "React", "Fullstack"],
        image: "https://images.unsplash.com/photo-1618477247222-ac59124c6da6?w=800&q=80",
        url: "#"
    },
    {
        id: 3,
        title: "Python for Data Science",
        provider: "Coursera",
        duration: "4 weeks",
        level: "Beginner",
        tags: ["Python", "Data Science", "Machine Learning"],
        image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=800&q=80",
        url: "#"
    },
    {
        id: 4,
        title: "CSS Mastery: Grid & Flexbox",
        provider: "YouTube",
        duration: "2h",
        level: "Intermediate",
        tags: ["CSS", "Frontend", "Design"],
        image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?w=800&q=80",
        url: "#"
    },
    {
        id: 5,
        title: "System Design Interview Guide",
        provider: "Educative",
        duration: "10h",
        level: "Advanced",
        tags: ["System Design", "Backend", "Architecture"],
        image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&q=80",
        url: "#"
    },
    {
        id: 6,
        title: "Modern JavaScript Deep Dive",
        provider: "FreeCodeCamp",
        duration: "8h",
        level: "Intermediate",
        tags: ["JavaScript", "Frontend", "Web"],
        image: "https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=800&q=80",
        url: "#"
    }
];
