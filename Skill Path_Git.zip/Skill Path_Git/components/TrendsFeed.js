import { ExternalLink } from "lucide-react";
import styles from "./TrendsFeed.module.css";
import { trends } from "@/data/trends";

export default function TrendsFeed() {
    return (
        <div className={styles.container}>
            <h3 className={styles.heading}>Trending in Tech</h3>
            <div className={styles.list}>
                {trends.map(item => (
                    <a key={item.id} href={item.url} className={styles.item}>
                        <div className={styles.category}>{item.category}</div>
                        <h4 className={styles.title}>{item.title}</h4>
                        <p className={styles.summary}>{item.summary}</p>
                        <div className={styles.meta}>
                            <span>{item.source}</span>
                            <span>•</span>
                            <span>{item.date}</span>
                        </div>
                        <ExternalLink size={14} className={styles.icon} />
                    </a>
                ))}
            </div>
        </div>
    );
}
