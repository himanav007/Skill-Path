"use client";
import { useState } from "react";
import { X, Plus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import styles from "./SkillSelector.module.css";

export default function SkillSelector({ skills, setSkills }) {
    const [inputValue, setInputValue] = useState("");

    const handleAdd = (e) => {
        e.preventDefault();
        if (inputValue.trim() && !skills.includes(inputValue.trim())) {
            setSkills([...skills, inputValue.trim()]);
            setInputValue("");
        }
    };

    const removeSkill = (skillToRemove) => {
        setSkills(skills.filter(s => s !== skillToRemove));
    };

    return (
        <div className={styles.container}>
            <h3 className={styles.heading}>Your Skills</h3>
            <div className={styles.tags}>
                <AnimatePresence>
                    {skills.map((skill) => (
                        <motion.span
                            key={skill}
                            initial={{ opacity: 0, scale: 0.8 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.8 }}
                            className={styles.tag}
                        >
                            {skill}
                            <button onClick={() => removeSkill(skill)} className={styles.removeBtn}>
                                <X size={14} />
                            </button>
                        </motion.span>
                    ))}
                </AnimatePresence>
            </div>

            <form onSubmit={handleAdd} className={styles.form}>
                <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Add a skill (e.g. Python)"
                    className={styles.input}
                />
                <button type="submit" className={styles.addBtn} disabled={!inputValue.trim()}>
                    <Plus size={20} />
                </button>
            </form>
        </div>
    );
}
