"use client";
import { useState } from "react";
import { Upload, FileText, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import styles from "./ResumeUpload.module.css";

export default function ResumeUpload({ onUploadComplete }) {
    const [isDragging, setIsDragging] = useState(false);
    const [file, setFile] = useState(null);
    const [isUploading, setIsUploading] = useState(false);

    const handleDrag = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === "dragenter" || e.type === "dragover") {
            setIsDragging(true);
        } else if (e.type === "dragleave") {
            setIsDragging(false);
        }
    };

    const processFile = (selectedFile) => {
        setFile(selectedFile);
        setIsUploading(true);

        // Simulate parsing delay and logic
        setTimeout(() => {
            setIsUploading(false);
            // Mock extracted skills based on file name or random
            const mockSkills = ["React", "JavaScript", "Next.js", "CSS", "Node.js"];
            onUploadComplete(mockSkills, selectedFile.name);
        }, 1500);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            processFile(e.dataTransfer.files[0]);
        }
    };

    const handleChange = (e) => {
        if (e.target.files && e.target.files[0]) {
            processFile(e.target.files[0]);
        }
    };

    return (
        <div
            className={`${styles.uploadArea} ${isDragging ? styles.active : ""} ${file ? styles.hasFile : ""}`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
        >
            <input type="file" id="resume-upload" className={styles.input} onChange={handleChange} accept=".pdf,.docx,.txt" />

            {file ? (
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className={styles.fileInfo}>
                    {isUploading ? (
                        <div className={styles.loader}>Parsing...</div>
                    ) : (
                        <>
                            <CheckCircle className="text-green-500" size={32} color="hsl(var(--primary))" />
                            <p>{file.name}</p>
                            <span className={styles.successText}>Resume Extracted!</span>
                        </>
                    )}
                </motion.div>
            ) : (
                <label htmlFor="resume-upload" className={styles.label}>
                    <Upload size={40} className={styles.icon} />
                    <p className={styles.text}>
                        Drag & Drop your resume here, or <span className={styles.highlight}>browse</span>
                    </p>
                    <span className={styles.subtext}>Supports PDF, DOCX, TXT</span>
                </label>
            )}
        </div>
    );
}
