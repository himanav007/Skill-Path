"use client";
import { motion } from "framer-motion";
import { Clock, BarChart, ExternalLink, Bookmark } from "lucide-react";
import Button from "@/components/ui/Button";
import styles from "./CourseCard.module.css";

export default function CourseCard({ course }) {
    return (
        <motion.div
            whileHover={{ y: -5 }}
            className={styles.card}
        >
            <div className={styles.imageWrapper}>
                <img src={course.image} alt={course.title} className={styles.image} />
                <div className={styles.overlay}>
                    <span className={styles.provider}>{course.provider}</span>
                </div>
            </div>

            <div className={styles.content}>
                <div className={styles.tags}>
                    {course.tags.slice(0, 2).map((tag) => (
                        <span key={tag} className={styles.tag}>{tag}</span>
                    ))}
                </div>

                <h3 className={styles.title}>{course.title}</h3>

                <div className={styles.meta}>
                    <div className={styles.metaItem}>
                        <Clock size={14} /> {course.duration}
                    </div>
                    <div className={styles.metaItem}>
                        <BarChart size={14} /> {course.level}
                    </div>
                </div>

                <div className={styles.actions}>
                    <Button variant="primary" className={styles.startBtn}>
                        Start <ExternalLink size={16} />
                    </Button>
                    <button className={styles.saveBtn}>
                        <Bookmark size={20} />
                    </button>
                </div>
            </div>
        </motion.div>
    );
}
