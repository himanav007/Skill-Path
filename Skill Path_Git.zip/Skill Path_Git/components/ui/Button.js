import { motion } from "framer-motion";
import styles from "./Button.module.css";

export default function Button({ children, variant = "primary", onClick, className = "" }) {
    return (
        <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`${styles.button} ${styles[variant]} ${className}`}
            onClick={onClick}
        >
            {children}
        </motion.button>
    );
}
