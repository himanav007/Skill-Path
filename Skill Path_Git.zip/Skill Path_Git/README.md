# SkillPath - AI Course Recommender

SkillPath is a modern web application that recommends free courses, tracks learning goals, and keeps you updated with the latest tech trends based on your skills.

## Features

- **Resume Upload**: Drag & Drop interface to parse skills from resumes.
- **Smart Recommendations**: Matches your skills to a curated list of free courses.
- **Learning Tracker**: Dashboard to track progress and daily streaks.
- **Tech Trends**: Real-time updates on technology news.

## Getting Started

1.  **Install Dependencies**:
    ```bash
    npm install
    ```

2.  **Run the App**:
    ```bash
    npm run dev
    ```

3.  **Open Browser**:
    Visit [http://localhost:3000](http://localhost:3000).

## Technologies Used

- **Next.js 15**: App Router & Server Components.
- **React 19**: Modern UI library.
- **Framer Motion**: Smooth animations.
- **Lucide React**: Beautiful icons.
- **CSS Modules**: Premium, scoped styling with CSS variables.

## Project Structure

- `app/`: Next.js App Router pages and layouts.
- `components/`: Reusable UI components.
- `data/`: Mock data for courses and trends.
- `lib/`: Utility functions (recommendation logic).
