"use client";
import { useState } from "react";
import ResumeUpload from "@/components/ResumeUpload";
import SkillSelector from "@/components/SkillSelector";
import Button from "@/components/ui/Button";
import { ArrowRight, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

export default function Onboarding() {
    const [step, setStep] = useState(1);
    const [skills, setSkills] = useState([]);
    const [resumeName, setResumeName] = useState("");

    const handleResumeUpload = (extractedSkills, name) => {
        setSkills((prev) => [...new Set([...prev, ...extractedSkills])]);
        setResumeName(name);
        // Auto advance after a brief pause
        setTimeout(() => setStep(2), 500);
    };

    return (
        <main style={{ maxWidth: "800px", margin: "0 auto", padding: "4rem 2rem", minHeight: "100vh" }}>
            <header style={{ marginBottom: "3rem", textAlign: "center" }}>
                <h1 className="animate-fade-in" style={{ fontSize: "2.5rem", fontWeight: "700", marginBottom: "0.5rem" }}>
                    Let's build your profile
                </h1>
                <p style={{ color: "hsl(var(--muted-foreground))" }}>
                    Step {step} of 2
                </p>
                <div style={{ height: "4px", width: "100%", background: "hsl(var(--secondary))", marginTop: "1rem", borderRadius: "2px", overflow: "hidden" }}>
                    <motion.div
                        animate={{ width: step === 1 ? "50%" : "100%" }}
                        style={{ height: "100%", background: "hsl(var(--primary))" }}
                    />
                </div>
            </header>

            {step === 1 && (
                <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
                    <h2 style={{ fontSize: "1.5rem", marginBottom: "1.5rem" }}>Upload your Resume</h2>
                    <ResumeUpload onUploadComplete={handleResumeUpload} />
                    <div style={{ marginTop: "2rem", textAlign: "center" }}>
                        <Button variant="outline" onClick={() => setStep(2)}>Skip this step</Button>
                    </div>
                </motion.div>
            )}

            {step === 2 && (
                <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
                    <h2 style={{ fontSize: "1.5rem", marginBottom: "1.5rem" }}>Refine your Skills</h2>
                    <SkillSelector skills={skills} setSkills={setSkills} />

                    <div style={{ marginTop: "3rem", display: "flex", justifyContent: "flex-end", gap: "1rem" }}>
                        <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
                        <a href="/dashboard">
                            <Button variant="primary">
                                Find Courses <Sparkles size={18} style={{ marginLeft: "0.5rem" }} />
                            </Button>
                        </a>
                    </div>
                </motion.div>
            )}
        </main>
    );
}
