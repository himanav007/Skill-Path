"use client";
import { useState, useEffect } from "react";
import CourseCard from "@/components/CourseCard";
import TrendsFeed from "@/components/TrendsFeed";
import Button from "@/components/ui/Button";
import { getRecommendedCourses } from "@/lib/recommendations";
import { motion } from "framer-motion";

export default function Dashboard() {
    const [skills, setSkills] = useState(["React", "JavaScript"]); // Default mocked skills
    const [recommended, setRecommended] = useState([]);
    const [progress, setProgress] = useState(65);

    useEffect(() => {
        // Determine skills source (local storage or mock)
        // For demo, we just use the mocked state
        setRecommended(getRecommendedCourses(skills));
    }, [skills]);

    return (
        <main style={{ maxWidth: "1200px", margin: "0 auto", padding: "2rem", minHeight: "100vh" }}>
            <header style={{ marginBottom: "2.5rem", display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
                <div>
                    <h1 style={{ fontSize: "2rem", fontWeight: "700", marginBottom: "0.5rem" }}>
                        Welcome back, Alex
                    </h1>
                    <p style={{ color: "hsl(var(--muted-foreground))" }}>
                        You're on a <span style={{ color: "hsl(var(--primary))", fontWeight: "600" }}>5-day streak</span>! Keep it up.
                    </p>
                </div>

                <div style={{ textAlign: "right", minWidth: "200px" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem", fontSize: "0.9rem" }}>
                        <span>Weekly Goal</span>
                        <span>{progress}%</span>
                    </div>
                    <div style={{ height: "8px", background: "hsl(var(--secondary))", borderRadius: "4px", overflow: "hidden" }}>
                        <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${progress}%` }}
                            transition={{ duration: 1, delay: 0.5 }}
                            style={{ height: "100%", background: "hsl(var(--primary))" }}
                        />
                    </div>
                </div>
            </header>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 350px", gap: "2rem" }}>
                {/* Left Column: Recommendations & Learning */}
                <section>
                    <h2 style={{ fontSize: "1.5rem", fontWeight: "600", marginBottom: "1.5rem" }}>
                        Recommended for your Path
                    </h2>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "1.5rem" }}>
                        {recommended.map((course, index) => (
                            <motion.div
                                key={course.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: index * 0.1 }}
                            >
                                <CourseCard course={course} />
                            </motion.div>
                        ))}
                    </div>

                    <h2 style={{ fontSize: "1.5rem", fontWeight: "600", margin: "3rem 0 1.5rem" }}>
                        Continue Learning
                    </h2>
                    {/* Mock "Active" Course */}
                    <div style={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", padding: "1.5rem", borderRadius: "0.75rem", display: "flex", alignItems: "center", gap: "1rem" }}>
                        <div style={{ width: "60px", height: "60px", background: "hsl(var(--secondary))", borderRadius: "0.5rem", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "700" }}>
                            JS
                        </div>
                        <div style={{ flex: 1 }}>
                            <h3 style={{ fontWeight: "600", marginBottom: "0.25rem" }}>Modern JavaScript Deep Dive</h3>
                            <div style={{ height: "6px", background: "hsl(var(--secondary))", borderRadius: "3px", width: "100%", maxWidth: "300px" }}>
                                <div style={{ width: "45%", height: "100%", background: "hsl(var(--primary))", borderRadius: "3px" }}></div>
                            </div>
                            <p style={{ fontSize: "0.8rem", color: "hsl(var(--muted-foreground))", marginTop: "0.5rem" }}>45% Complete</p>
                        </div>
                        <Button variant="outline">Resume</Button>
                    </div>
                </section>

                {/* Right Column: Trends */}
                <aside>
                    <TrendsFeed />
                </aside>
            </div>
        </main>
    );
}
