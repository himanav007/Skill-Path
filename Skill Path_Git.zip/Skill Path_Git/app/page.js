"use client";
import Button from "@/components/ui/Button";
import { ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <main style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      textAlign: "center",
      gap: "2rem",
      padding: "2rem"
    }}>
      <h1 className="animate-fade-in" style={{ fontSize: "4rem", fontWeight: "800", letterSpacing: "-0.05em" }}>
        Skill<span style={{ color: "hsl(var(--primary))" }}>Path</span>
      </h1>
      <p style={{ maxWidth: "600px", color: "hsl(var(--muted-foreground))", fontSize: "1.25rem" }}>
        Analyze your skills. Discover free courses. Track your growth.
      </p>

      <div style={{ display: "flex", gap: "1rem" }}>
        <a href="/onboarding">
          <Button variant="primary">
            Get Started <ArrowRight size={20} />
          </Button>
        </a>
        <Button variant="outline">
          Learn More
        </Button>
      </div>
    </main>
  );
}
